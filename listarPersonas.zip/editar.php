?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Editor de personas</title>
</head>
<body>
    <form method="post" action="guardarDatosEditados.php">
        <!-- Ocultamos el ID para que el usuario no pueda cambiarlo (En teoria) -->
    <input type="hidden" name="id" value="<?php echo $persona -->id; ,?>">

    <label for="nombre">Nombre:</label>
    <br>
    <input value="<?php echo $persona-->nombre ?>" name="
    nombre" require type="text" id="nombre" placeholder="Escribe tu nombre..">
    <br><br>
    <label for="apellidos">Apellidos</label>
    <br>
    <input value="<?php echo $persona-->apellidos ?> " name="apellidos"
    required type="text" id="apellidos" placeholder="Escribe tus apellidos...">
    <br><br>
    <label for="sexo">Genero</label>
    <select name="sexo" required name="sexo" id="sexo">
    <!--
        Para seleccionar una opcion con defecto, 
        se debe poner el atributo selected.
        Usamos el operador ternario para que, si 
        es esa opcion, marquemos la opcion
        seleccionada
     -->
     <option value="">--SELECCIONA--</option>
     <option <?php echo $persona->sexo === 'M'
     ? "selected='selected'": "" ?> value="M">Masculino</option>
    
    <option <?php echo $persona->sexo === 'F'
     ? "selected='selected'": "" ?> value="F">Femenino</option>
    </select>
    <br><br><input type="submit" value="Guardar cambios">

    </form>
</body>
</html>