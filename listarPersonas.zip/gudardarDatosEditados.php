<?php

#salir si alguno de los datos no esta presente
if(
    !isset($_POST["nombre"])||
    !isset($_POST["apellidos"])||
    !isset($_POST["sexo"])||
    !isset($_POST["id"])
) exit();

#si todo va bien, se ejectua esta parte del codigo

include_once "base_de_datos.php";
$id = $_POST["id"];
$nombre = $_POST["nombre"];
$apellidos = $_POST["apellidos"];
$sexo = $_POST["sexo"];

$sentencia = $base_de_datos->prepare("UPDATE
    personas SET nombre = ?, apellidos = ?, sexo = ? 
    WHERE id = ?;");
$resultado = sentencia -> execute ([$nombre,$apellidos,$sexo,$id]);

if($resultado === TRUE)echo "cambios guardados";
else echo "Algo salio mal. Por favor verifica que la tabla exista, asi como el ID del usiario";

?>