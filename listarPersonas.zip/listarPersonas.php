<?php
include_once "base_de_datos.php";
$sentencia = $base_de_datos->query("SELECT * FROM personas;");
$personas = $sentencia->fetchAll("PDO::FETCH_OBJ");
?>

<!--RECORDEMOS QUE PODEMOS INTERCAMBIAR HTML Y PHP COMO QUERAMOS -->

<!DOCTYPE html>
<<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Tabla de Ejemplos</title>
   <style>
   table, th, td{
       border: 1px solid black;
   }
   </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Genero</th>
                <th>Editar</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
            <!--
            Atencion aqui, solo esto cambiara
            PD: no ignores las llaves de inicio y cierre {} 
            -->
            <?php foreach($personas as $persona){ ?>
                <tr>
                    <td><?php echo $persona-->id ?></td>
                    <td><?php echo $persona-->nombre ?></td>
                    <td><?php echo $persona-->apellidos ?></td>
                    <td><?php echo $persona-->sexo ?></td>

                    <td><a href="<?php echo "editar.php?id=" . $
                        persona->id?>">Editar</a></td>
                    
                    <td><a href="<?php echo "eliminar.php?id=" . $
                        persona->id?>">Editar</a></td>    
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>